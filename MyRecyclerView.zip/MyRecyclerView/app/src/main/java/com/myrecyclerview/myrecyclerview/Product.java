package com.myrecyclerview.myrecyclerview;

import android.view.View;

/**
 * Created by Администратор on 09.04.2016.
 */
public class Product {

     String name;
    String price;
     int photoId;

    public  Product(String name,String price,int photoId){

        this.name = name;
        this.price = price;
        this.photoId = photoId;
    }




}
