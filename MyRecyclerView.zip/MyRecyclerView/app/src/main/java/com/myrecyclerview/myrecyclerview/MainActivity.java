package com.myrecyclerview.myrecyclerview;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

;import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    List<Product> products;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rv = (RecyclerView) findViewById(R.id.rv);

        fillData();

        GridLayoutManager GridLayoutManager = new GridLayoutManager(this,2);
        rv.setLayoutManager(GridLayoutManager);

        RVAdapter adapter = new RVAdapter(products);
        rv.setAdapter(adapter);

    }

    private void fillData(){

        products = new ArrayList<Product>();

        for (int i = 0; i < 50 ; i++) {
            products.add(new Product("Swimming pool" + i,"120000" + i,R.drawable.intex));
        }

    //    products.add(new Product("Swimming pool1","1200000",R.drawable.intex));
    //    products.add(new Product("Swimming pool2","2000000",R.drawable.intex));
    //    products.add(new Product("Swimming pool3","2300000",R.drawable.intex));


    }



}
