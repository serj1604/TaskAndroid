package com.myprojectfragments.myprojectfragments.fragments;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.myprojectfragments.myprojectfragments.db.DbHelper;
import com.myprojectfragments.myprojectfragments.adapters.PagerAdapterPic;
import com.myprojectfragments.myprojectfragments.beans.Picture;
import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.R;
import com.myprojectfragments.myprojectfragments.adapters.RVPictureAdapter;
import com.myprojectfragments.myprojectfragments.activity.GameActivity;
import com.myprojectfragments.myprojectfragments.activity.MainActivityProduct;

import android.support.v4.app.Fragment;

import java.util.List;
import java.util.Vector;

/**
 * Created by Администратор on 12.05.2016.
 */
public class ProductFragment extends BaseFragment {

    private  static final String TAG= ProductFragment.class.getSimpleName();
    private DbHelper dbHelper;
    private List<Product> products;
    private List<Picture> pictures;
    private List<Fragment> fragments;

    private PagerAdapter myAdapter;

    private Picture pic;
    private RecyclerView rv;
    private RVPictureAdapter adapter = null;


    private TextView tv_url;
    private TextView  tv_typePrefix;
    private TextView  tv_model;
    private TextView  tv_verdor;
    private TextView  tv_price;
    private TextView  tv_picture;
    private TextView  tv_par1;
    private TextView  tv_par2;
    private TextView  tv_par3;
    private TextView  tv_par4;
    private TextView  tv_par5;




    private Context context;

    private Button buttgame;
    private Button buttpay;


    private String url_prod ;
    private String price_prod ;
    private String typePrefix_prod ;
    private String verdor_prod  ;
    private String model_prod ;
    private String par1 ;
    private String par2 ;
    private String par3 ;
    private String par4 ;
    private String par5 ;

    private String category_prod ;



    public static ProductFragment getInstance(FragmentManager fragmentManager) {


        ProductFragment myFragment = (ProductFragment) fragmentManager.findFragmentByTag(ProductFragment.TAG);

        if (myFragment == null) {
            myFragment = new ProductFragment();


        }

        return myFragment;

    }



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_product, container,false);

        tv_url = (TextView) view.findViewById(R.id.tv_url);
        tv_typePrefix = (TextView) view.findViewById(R.id.tv_typePrefix);
        tv_model = (TextView) view.findViewById(R.id.tv_model);
        tv_verdor = (TextView) view.findViewById(R.id.tv_verdor);
        tv_price = (TextView) view.findViewById(R.id.tv_price);
        tv_picture = (TextView) view.findViewById(R.id.tv_picture);
        tv_par1 = (TextView) view.findViewById(R.id.tv_par1);
        tv_par2 = (TextView) view.findViewById(R.id.tv_par2);
        tv_par3 = (TextView) view.findViewById(R.id.tv_par3);
        tv_par4 = (TextView) view.findViewById(R.id.tv_par4);
        tv_par5 = (TextView) view.findViewById(R.id.tv_par5);
        buttgame = (Button) view.findViewById(R.id.buttgame);
        buttpay = (Button) view.findViewById(R.id.buttpay);



        dbHelper = new DbHelper(getActivity().getApplicationContext());
        products = dbHelper.getProduct_db_list();

            url_prod = products.get(0).getProd_url();

            typePrefix_prod =products.get(0).getTypePrefix();
            verdor_prod = products.get(0).getVerdor();
            model_prod = products.get(0).getModel();
            price_prod= products.get(0).getPrice();





            par1= products.get(0).getParam1();
            par2= products.get(0).getParam2();
            par3= products.get(0).getParam3();
            par4= products.get(0).getParam4();

            par5 = products.get(0).getParam5();


        category_prod = products.get(0).getCategory();


    //    tv_url.setText("URL: " +url_prod);
        tv_typePrefix.setText("Название товара: " + typePrefix_prod);
        tv_model.setText(model_prod);
        tv_verdor.setText("Модель: " +verdor_prod);
        tv_price.setText("Цена товара: " +price_prod + " р.");



    if (Integer.valueOf(category_prod)==9||Integer.valueOf(category_prod)==10) {




            tv_par1.setText("Объём: " + par1);
            tv_par2.setText("Длина: " + par2);






            if(par5==null || par5.equals("null")) {

                tv_par3.setText("Ширина: " + par3);
                tv_par4.setText("Вес : " + par4);
                tv_par5.setText("");
            }else {
                tv_par3.setText("Ширина: " + par3);
                tv_par4.setText("Высота : " + par4);
                tv_par5.setText("Вес: " +par5);



            }


    }


        if (category_prod.equals(String.valueOf(14))){

            tv_par1.setText("Диаметр " + par1);
            tv_par2.setText("Вес: " + par2);
            tv_par3.setText("");
            tv_par4.setText("");
            tv_par5.setText("");



        }


        if (category_prod.equals(String.valueOf(12))){

            tv_par1.setText("Диаметр " + par1);
            tv_par2.setText("Вес: " + par2);
            tv_par3.setText("");
            tv_par4.setText("");
            tv_par5.setText("");



        }


    if (category_prod.equals(String.valueOf(16))) {


        if (par3 == null||par3.equals("null")) { //тогда 2 параметров


            tv_par1.setText("Диаметр " + par1);
            tv_par2.setText("Вес: " + par2);
            tv_par3.setText("");
            tv_par4.setText("");
            tv_par5.setText("");



        }else { //3 параметра

            tv_par1.setText("Длина " + par1);
            tv_par2.setText("Ширина: " + par2);
            tv_par3.setText("Вес: " + par3);
            tv_par4.setText("");
            tv_par5.setText("");


        }


    }

        if (Integer.valueOf(category_prod)==15) {
            tv_par1.setText("Совместимость: " + par1);
            tv_par2.setText("Вес: " + par2);
            tv_par3.setText("");
            tv_par4.setText("");
            tv_par5.setText("");


        }


        if (Integer.valueOf(category_prod)==11) {

        if (par4 != null||!par4.equals("null")) { //тогда 3 параметров
            tv_par1.setText("Ширина: " + par1);
            tv_par2.setText("Длина: " + par2);
            tv_par3.setText("Высота " + par3);
            tv_par4.setText("Вес: " + par4);
            tv_par5.setText("");


        }else  if (par3 != null||!par3.equals("null")) { //тогда 3 параметров


                tv_par1.setText("Ширина: " + par1);
                tv_par2.setText("Длина: " + par2);
                tv_par3.setText("Вес " + par3);
                tv_par4.setText("");
                tv_par5.setText("");




            }else { //2 параметра

                tv_par1.setText("Длина/Совместимость " + par1);
                tv_par2.setText("Вес: " + par2);
                tv_par3.setText("");
                tv_par4.setText("");
                tv_par5.setText("");


            }




        }
        if (Integer.valueOf(category_prod)==13) {

            tv_par1.setText("Производительность/Длина:" + par1);
            tv_par2.setText("Напряжение/Объём: " + par2);
            tv_par3.setText("Вес: " + par3);


        }






        fragments = new Vector<>();

        fragments.add(Fragment.instantiate(getActivity(), Fragment_pic1.class.getName()));
        fragments.add(Fragment.instantiate(getActivity(), Fragment_pic2.class.getName()));
        fragments.add(Fragment.instantiate(getActivity(), Fragment_pic3.class.getName()));

        myAdapter = new PagerAdapterPic(getChildFragmentManager(),fragments);


        ViewPager pager =(ViewPager)view.findViewById(R.id.pager);

        pager.setAdapter(myAdapter);
        pager.setCurrentItem(0);






        buttgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                try {
                    Intent intent = new Intent((MainActivityProduct) getActivity(), GameActivity.class);
                    ((MainActivityProduct) getActivity()).startActivity(intent);
                }catch (Exception e){

                }

            }
        });

        buttpay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             //   Intent intent = new Intent((MainActivityProduct) getActivity(), GameActivity.class);
             //   ((MainActivityProduct) getActivity()).startActivity(intent);

                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.valueOf(url_prod)));
                ((MainActivityProduct) getActivity()).startActivity(browserIntent);


            }
        });






        return  view;

    }




    @Override
    public String getFragmentTag() {
        return TAG;
    }
}
