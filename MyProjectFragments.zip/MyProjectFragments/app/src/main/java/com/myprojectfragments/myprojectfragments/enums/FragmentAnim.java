package com.myprojectfragments.myprojectfragments.enums;


public enum FragmentAnim {

    NONE, RIGHT_TO_LEFT

}
