package com.myprojectfragments.myprojectfragments.activity;



//import android.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.myprojectfragments.myprojectfragments.R;
import com.myprojectfragments.myprojectfragments.activity.MainActivity;

public class MainActivityInfo extends AppCompatActivity  {



    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        setContentView(R.layout.activity_main_info);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
     //   BaseFragment frag1 = new FragmentNotInternet();
    //    switchFragment(frag1,true,FragmentAnim.RIGHT_TO_LEFT);





    }

    @Override
    public void onBackPressed() {

          Intent intent = new Intent(this, MainActivity.class);
          startActivity(intent);
        this.finish();

     //   super.onBackPressed();
    }
}
