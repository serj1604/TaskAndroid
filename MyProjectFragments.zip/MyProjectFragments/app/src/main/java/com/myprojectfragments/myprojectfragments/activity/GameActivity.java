package com.myprojectfragments.myprojectfragments.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.myprojectfragments.myprojectfragments.constants.Constants;
import com.myprojectfragments.myprojectfragments.db.DbHelper;
import com.myprojectfragments.myprojectfragments.db.DbHelperCode;
import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.R;

import java.util.List;


public class GameActivity extends AppCompatActivity {

    private DbHelper dbHelper;
    private DbHelperCode dbHelper1;

    private Context context;
    private List<Product> products;
    private Button butt1;
    private Button butt2;
    private Button butt3;
    private TextView tv_bank;
    private TextView tv_stavka;
    private TextView code;

    private int randomNumber;

    private Double bank;
    private Double stavka ;
    private Double stavka1 ;

    private int  diffstavka ;
    private Double firstBank;
    private  double firstPrice;
    private Double maxBank;
    private Double probBank;
    private Double helpBankNew;


    //для базы данных таблица 3!!!

    private int db3_id_prod ;
    private String db3_url_prod ;
    private String db3_picture_prod;
    private String db3_picture_prod1;
    private String db3_picture_prod2;
    private String db3_typePrefix_prod;
    private String db3_verdor_prod;

    private String db3_model_prod;
    private String db3_price_prod;
    private String db3_category_prod;
    private String db3_param1_prod;
    private String db3_param2_prod;
    private String db3_param3_prod;
    private String db3_param4_prod;
    private String db3_param5_prod;



    /// для кола
    private Button butt4finish;
    private int prod_id;
    private String [] code_par1 = {"erg","apy","pra","qwh","cdp","xsp","spq","anm","azp","wdp","afl"};
    private String [] code_par2 = {"cbq","lgc","svl","lwq","pda","qax","psa","prw","qer","zqp","cqr"};
    private String [] code_par3 = {"qpg","xar","qwp","cxe","lpr","qpf","bsr","pae","tra","cpw","org"};
    private int parN1; // номер параметра
    private int parN2; // номер параметра
    private int parN3; // номер параметра
    private String par1;
    private String par2;
    private String par3;
    private  Double par4;

    private String str_par_4;
    private String str_par_4_1;
    private  String allCode;




    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        //----action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        iv = (ImageView) findViewById(R.id.imageView);
        butt1 = (Button) findViewById(R.id.butt1);
        butt2 = (Button) findViewById(R.id.butt2);
        butt3 = (Button) findViewById(R.id.butt3);
        butt4finish  = (Button) findViewById(R.id.butt4finish);
        tv_bank = (TextView) findViewById(R.id.tv_bank);
        tv_stavka = (TextView) findViewById(R.id.tv_stavka);

        code = (TextView) findViewById(R.id.code);
        //---------------получение банк---------------------

     //   Intent intent = getIntent();


       // когда сумма больше 100 000

        dbHelper = new DbHelper(getApplicationContext());
        products = dbHelper.getProduct_db_list();

        //  для таблицы 3!!!!!!!!!!!!!!!!
        db3_id_prod = products.get(0).getProd_id();
        db3_url_prod = products.get(0).getProd_url();
        db3_picture_prod = products.get(0).getPicture();
        db3_picture_prod1= products.get(0).getPicture1();
        db3_picture_prod2= products.get(0).getPicture2();
        db3_typePrefix_prod= products.get(0).getTypePrefix();
        db3_verdor_prod= products.get(0).getVerdor();

        db3_model_prod= products.get(0).getModel();
        db3_price_prod= products.get(0).getPrice();
        db3_category_prod= products.get(0).getCategory();
        db3_param1_prod= products.get(0).getParam1();
        db3_param2_prod= products.get(0).getParam2();
        db3_param3_prod= products.get(0).getParam3();
        db3_param4_prod= products.get(0).getParam4();
        db3_param5_prod= products.get(0).getParam5();


        //-------------------------------------



//  URL!!!!!
       String url_prod = products.get(0).getProd_url();

        prod_id = products.get(0).getProd_id();


        firstPrice = Double.valueOf(products.get(0).getPrice());
        probBank = Double.valueOf(products.get(0).getPrice());
        firstBank = Double.valueOf(products.get(0).getPrice());



          if(probBank/ Constants.INT_1000>Constants.INT_99) {

              stavka1 = Constants.DOUB_1000;
              firstBank = ((firstBank / Constants.INT_100 * 1) -((firstBank / Constants.INT_100)%stavka1));
              maxBank = firstBank * Constants.INT_6;
              Log.d(" firstBank", String.valueOf(firstBank));
              stavka = Constants.DOUB_1000;
              diffstavka = Constants.INT_1000;

          }else if((probBank/Constants.INT_1000<Constants.INT_99) &&(probBank/Constants.INT_1000>0) ){

              stavka1 = Constants.DOUB_100;
              firstBank = ((firstBank / Constants.INT_100 * 1) -((firstBank / Constants.INT_100)%stavka1));
              maxBank = firstBank * Constants.INT_6;
              Log.d(" firstBank", String.valueOf(firstBank));
              stavka = Constants.DOUB_100;
              diffstavka = Constants.INT_100;

          }
           else if((probBank<Constants.INT_1000&&probBank>Constants.INT_10) ){  // после денаминации

                  stavka1 = 0.1;

                  if(firstBank % Constants.INT_100!=0 &&firstBank % Constants.INT_100>Constants.INT_10 ) {
                      firstBank = ((firstBank / Constants.INT_100) - ((firstBank % Constants.INT_100) / Constants.INT_100));
                  }else {
                      firstBank = ((firstBank / Constants.INT_100));
                  }

                  maxBank = firstBank * Constants.INT_6;
                  Log.d(" firstBank", String.valueOf(firstBank));
                  stavka = 0.1;
                  diffstavka = 1;

          }

        //------------------------------------------------


        bank = firstBank;
        tv_bank.setText(String.valueOf(bank));
        tv_stavka.setText(String.valueOf(stavka));

        iv.setBackgroundResource(R.drawable.animation);
        final AnimationDrawable animcoin = (AnimationDrawable) iv.getBackground();
        animcoin.start();

        butt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  v.setClickable(false); //не активная кнопка после нажатия
                butt1.setClickable(false);
                butt2.setClickable(false);
                butt3.setClickable(true);


                RandomNumber();

                if (randomNumber < Constants.INT_6) {  //орел
                    //выводить орел
                    bank = bank + stavka;

                    // проверка на maxBank
                    if (bank < maxBank) {

                        tv_bank.setText(String.valueOf(bank));
                        animcoin.stop();
                        iv.setBackgroundResource(R.drawable.picture_10);
                        Toast.makeText(getApplicationContext(), "+" + stavka, Toast.LENGTH_SHORT).show();

                        // butt1.setText(String.valueOf(randomNumber));
                    } else {
                        //max выигрыш
                        animcoin.stop();
                        iv.setBackgroundResource(R.drawable.picture_10);
                        tv_bank.setText(String.valueOf(bank));
                        // butt3.Visible(false);
                        butt3.setVisibility(View.INVISIBLE);
                        butt4finish.setVisibility(View.VISIBLE);

                        Toast.makeText(getApplicationContext(), "You win! Max Bank", Toast.LENGTH_SHORT).show();


                    }


                } else {

                    //выводить решка


                    bank = bank - stavka;

                    if (bank > 0) {

                        tv_bank.setText(String.valueOf(bank));
                        animcoin.stop();
                        iv.setBackgroundResource(R.drawable.picture_1);
                        Toast.makeText(getApplicationContext(), "-" + stavka, Toast.LENGTH_SHORT).show();

                        //  butt1.setText("loser");
                    } else {


                        iv.setBackgroundResource(R.drawable.picture_1);
                        tv_bank.setText(String.valueOf(bank));
                        // butt3.Visible(false);
                        butt3.setVisibility(View.INVISIBLE);
                        Toast.makeText(getApplicationContext(), "You lose!", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });

        butt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //v.setClickable(false);// не активная кнопка после нажатия
                butt1.setClickable(false);
                butt2.setClickable(false);
                butt3.setClickable(true);

                RandomNumber();


                if(randomNumber>  Constants.INT_5) {  //решка
                    bank = bank + stavka;


                    if (bank < maxBank) {


                        tv_bank.setText(String.valueOf(bank));
                        animcoin.stop();
                        iv.setBackgroundResource(R.drawable.picture_1);
                        Toast.makeText(getApplicationContext(), "+" + stavka, Toast.LENGTH_SHORT).show();
                    }else{

                        //max выигрыш
                        animcoin.stop();
                        iv.setBackgroundResource(R.drawable.picture_1);
                        tv_bank.setText(String.valueOf(bank));
                        // butt3.Visible(false);
                        butt3.setVisibility(View.INVISIBLE);
                        butt4finish.setVisibility(View.VISIBLE);
                        Toast.makeText(getApplicationContext(), "You win! Max Bank" , Toast.LENGTH_SHORT).show();



                    }


                    //butt2.setText(String.valueOf(randomNumber));
                } else {

                    //вернуть!!!!!!!   -
                    bank = bank - stavka;
                    if (bank > 0) {
                        tv_bank.setText(String.valueOf(bank));
                        animcoin.stop();
                        iv.setBackgroundResource(R.drawable.picture_10);
                        Toast.makeText(getApplicationContext(), "-" + stavka, Toast.LENGTH_SHORT).show();
                        //butt2.setText("loser");
                    }else{
                        iv.setBackgroundResource(R.drawable.picture_10);
                        tv_bank.setText(String.valueOf(bank));
                        butt3.setVisibility(View.INVISIBLE);
                        Toast.makeText(getApplicationContext(), "You lose!" , Toast.LENGTH_SHORT).show();
                    }

                }


            }
        });

        butt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                v.setClickable(false);
                diffStavka();
                butt1.setClickable(true);
                butt2.setClickable(true);
                iv.setBackgroundResource(R.drawable.animation);
                final AnimationDrawable animcoin = (AnimationDrawable) iv.getBackground();
                animcoin.start();

            }
        });


        //вывод кода
        butt4finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                discountCode();

            }
        });



    }


    public void RandomNumber(){

        randomNumber = (int)(Math.random()*Constants.INT_10+1 );// 1-10
        Log.d(" RandomNumber", String.valueOf(randomNumber));

    }

    public void RandomPar(){
        parN1 = (int)(Math.random()*Constants.INT_10 );// 1-10

    }

    public void diffStavka(){



        diffstavka  = (int)(Math.random()*Constants.INT_10+1 );
        if (bank > diffstavka*stavka1 )
            stavka = diffstavka*stavka1;
        else
            stavka = stavka1;
        tv_stavka.setText(String.valueOf(stavka));
        Log.d("stavka", String.valueOf(diffstavka));
    }


    //формирование discoutCode
    public  void discountCode() {

        par4 =  ((firstPrice - bank)/firstPrice);
        Log.d("par4", String.valueOf(par4));
        str_par_4 = String.valueOf(par4);
        if(str_par_4.length()>8) {
            str_par_4_1 = str_par_4.substring(2, 7);
        }else{
            str_par_4_1 = str_par_4.substring(2,str_par_4.length() );
        }

        RandomPar();
        par1 = code_par1[parN1];
        RandomPar();
        par2 = code_par2[parN1];
        RandomPar();
        par3 = code_par3[parN1];

        allCode = par1 + String.valueOf(prod_id) +par2  + str_par_4_1 +par3;
        butt4finish.setText(allCode);

        //сохранение в 3-ю базу


        dbHelper1 = new DbHelperCode(getApplicationContext());


    //    dbHelper1.deleteRowTabALL();


        Log.d("dbHelper", "start dbHelper");
        dbHelper1.saveALL(

                Integer.valueOf(db3_id_prod),
                String.valueOf(db3_url_prod),
                String.valueOf(db3_price_prod),
                String.valueOf(db3_category_prod),
                String.valueOf(db3_picture_prod),
                String.valueOf(db3_picture_prod1),
                String.valueOf(db3_picture_prod2),
                String.valueOf(db3_typePrefix_prod),
                String.valueOf(db3_verdor_prod),
                String.valueOf(db3_model_prod),
                String.valueOf(db3_param1_prod),
                String.valueOf(db3_param2_prod),
                String.valueOf(db3_param3_prod),
                String.valueOf(db3_param4_prod),
                String.valueOf(db3_param5_prod),
                String.valueOf(bank),
                String.valueOf(str_par_4),
                String.valueOf(allCode)


        );



        Log.d("dbHelper", "end dbHelper");


        Intent intent = new Intent(GameActivity.this, MainActivityCode.class);
        /*
        intent.putExtra("key_url", prod.getProd_url());
        intent.putExtra("key_price", prod.getPrice());
        intent.putExtra("key_picture", prod.getPicture());
        intent.putExtra("key_typePrefix", prod.getTypePrefix());
        intent.putExtra("key_verdor", prod.getVerdor());
        intent.putExtra("key_model", prod.getModel());
      */

        startActivity(intent);

        Log.d("allCode", String.valueOf(allCode));


    }









}
