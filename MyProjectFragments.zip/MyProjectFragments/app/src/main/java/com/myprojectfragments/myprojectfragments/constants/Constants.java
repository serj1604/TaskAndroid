package com.myprojectfragments.myprojectfragments.constants;

/**
 * Created by Администратор on 26.05.2016.
 */
public class Constants {

    public static final String CATEG_ALL = "Все";
    public static final String CATEG_9 = "Надувные бассейны";
    public static final String CATEG_10 = "Каркасные бассейны";
    public static final String CATEG_11 = "Надувные матрасы";
    public static final String CATEG_12 = "Надувные круги";
    public static final String CATEG_13 = "Насосы для бассейнов, ремкомплекты";
    public static final String CATEG_14 = "Надувные мячи";
    public static final String CATEG_15 = "Аксессуары";
    public static final String CATEG_16 = "Тенты и подстилки для бассейнов";
    //for game
    public static final int INT_100 = 100;
    public static final int INT_10 = 10;
    public static final int INT_1000 = 1000;
    public static final int INT_99 = 99;
    public static final int INT_6 = 6;
    public static final int INT_5 = 5;


    public static final Double DOUB_1000 = 1000.0;
    public static final Double DOUB_100 = 100.0;







}
