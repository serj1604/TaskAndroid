package com.myprojectfragments.myprojectfragments.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

import java.util.List;

/**
 * Created by Администратор on 14.05.2016.
 */
public class PagerAdapterPic  extends FragmentPagerAdapter{
    private List<Fragment> fragments;
    List<View> pages = null;

    public PagerAdapterPic(FragmentManager fm,List<Fragment> fragments ) {
        super(fm);
        this.fragments = fragments;

    }



    @Override
    public Fragment getItem(int position) {
        return this.fragments.get(position);
    }

    @Override
    public int getCount() {
        return this.fragments.size();
    }

}
