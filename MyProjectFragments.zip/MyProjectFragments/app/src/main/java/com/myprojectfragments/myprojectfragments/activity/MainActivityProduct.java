package com.myprojectfragments.myprojectfragments.activity;





import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import com.myprojectfragments.myprojectfragments.fragments.BaseFragment;
import com.myprojectfragments.myprojectfragments.db.DbHelper;
import com.myprojectfragments.myprojectfragments.enums.FragmentAnim;
import com.myprojectfragments.myprojectfragments.fragments.ProductFragment;
import com.myprojectfragments.myprojectfragments.R;
import com.myprojectfragments.myprojectfragments.listeners.ToolbarListener;


public class MainActivityProduct extends AppCompatActivity implements ToolbarListener {
    private DbHelper dbHelper;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_probnik);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ProductFragment pf = new ProductFragment();

              switchFragment(pf,false, FragmentAnim.RIGHT_TO_LEFT);

    }


    public void showFragment(BaseFragment fragment, boolean addToBackStack, FragmentAnim fragmentAnim){


        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();


        if(fragmentAnim == FragmentAnim.RIGHT_TO_LEFT) {
            transaction.setCustomAnimations(R.anim.fragment_enter_from_right, R.anim.fragment_exit_to_left,
                    R.anim.fragment_enter_from_left, R.anim.fragment_exit_to_right);
        }




        transaction.replace(R.id.container, fragment,fragment.getFragmentTag());
        if(addToBackStack){

            transaction.addToBackStack(null);                                                         //TabLayout GitHub
        }


        transaction.commit();


    }








    @Override
    public void switchFragment(BaseFragment fragment, boolean addToBackStack, FragmentAnim fragmentAnim) {
        showFragment(fragment,addToBackStack, fragmentAnim);

    }


}
