package com.myprojectfragments.myprojectfragments.activity;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.common.api.GoogleApiClient;
import com.myprojectfragments.myprojectfragments.db.DbHelperCode;
import com.myprojectfragments.myprojectfragments.parses.ParseMagic;
import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.handlers.Producthandler;
import com.myprojectfragments.myprojectfragments.R;
import com.myprojectfragments.myprojectfragments.adapters.RVAdapterCode;

import java.util.List;


public class MainActivityCode extends AppCompatActivity {

  Context context;
    Producthandler XMLHandler = new Producthandler();

    private static final String TAG = "MainActivity for photo";
    private DbHelperCode dbHelper;
    //List<Product> products;

    RVAdapterCode adapter = null;
    List<Product> products;
    ParseMagic mt;
    RecyclerView rv;

    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_code);
        //----action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        rv = (RecyclerView) findViewById(R.id.rv_code);


        dbHelper = new DbHelperCode(getApplicationContext());
        //   dbHelper.deleteRowTabALL( );
        products = dbHelper.getProduct_db_list_all();


        LinearLayoutManager GridLayoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(GridLayoutManager);

        adapter = new RVAdapterCode(getApplicationContext(),products);

        rv.setAdapter(adapter);


        rv.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rv, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Product prod = products.get(position);
                Toast.makeText(getApplicationContext(), prod.getModel() + " is selected!", Toast.LENGTH_SHORT).show();

                //переход на страницу заказа
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.valueOf(prod.getProd_url())));
                startActivity(browserIntent);




            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }



    @Override
    public void onStart() {
        super.onStart();


    }

    @Override
    public void onStop() {
        super.onStop();

    }

// нажатие в recycler List!!!


    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "Background thread destroyed");

    }
}