package com.myprojectfragments.myprojectfragments.listeners;


import com.myprojectfragments.myprojectfragments.fragments.BaseFragment;
import com.myprojectfragments.myprojectfragments.enums.FragmentAnim;

public interface ToolbarListener {

   // void setTitle(CharSequence name) ;

  //  void setTitle(int resTitleId);
 //   void  switchFragment(BaseFragment fragment, boolean addToBackStack, boolean clearBackStack, FragmentAnim fragmentAnim);
    void  switchFragment(BaseFragment fragment, boolean addToBackStack,FragmentAnim fragmentAnim);

}
