package com.myprojectfragments.myprojectfragments.activity;



//import android.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.myprojectfragments.myprojectfragments.fragments.BaseFragment;
import com.myprojectfragments.myprojectfragments.constants.Constants;
import com.myprojectfragments.myprojectfragments.db.DbHelper;
import com.myprojectfragments.myprojectfragments.enums.FragmentAnim;
import com.myprojectfragments.myprojectfragments.parses.ParseMagic;
import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.R;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragment;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg10;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg11;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg12;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg13;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg14;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg15;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg16;
import com.myprojectfragments.myprojectfragments.fragments.RecyclerViewFragmentCateg9;
import com.myprojectfragments.myprojectfragments.listeners.ToolbarListener;
import com.myprojectfragments.myprojectfragments.adapters.ViewPagerAdapter;

import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity implements ToolbarListener {
    private DbHelper dbHelper;

    Intent intent;
    Toolbar toolbar;
    TabLayout tabLayout;
    ViewPager viewPager;
    ViewPagerAdapter viewPagerAdapter;
    List<Fragment> fragments;
    ParseMagic mt;
    List<Product> products;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {





        super.onCreate(savedInstanceState);
       //getSupportActionBar().setDisplayHomeAsUpEnabled(true);


     //   ActionBar actionBar = getSupportActionBar();
    //    actionBar.setIcon(R.mipmap.ic_launcher);

     //  getSupportActionBar().setLogo(R.mipmap.ic_launcher);
    //   getSupportActionBar().setDisplayUseLogoEnabled(true);



        setContentView(R.layout.activity_main);



   try {


       dbHelper = new DbHelper(getApplicationContext());






           dbHelper.deleteRowTabALL();
           mt = new ParseMagic();
           mt.execute();

           try {
               products = mt.get();
           } catch (InterruptedException e) {
               e.printStackTrace();
           } catch (ExecutionException e) {
               e.printStackTrace();
           }





           for(int i=0;i<products.size();i++){

               dbHelper.saveALL(
                       Integer.valueOf(products.get(i).getProd_id()),
                       String.valueOf(products.get(i).getProd_url()),
                       String.valueOf(products.get(i).getPrice()),
                       String.valueOf(products.get(i).getCategory()),
                       String.valueOf(products.get(i).getPicture()),
                       String.valueOf(products.get(i).getPicture1()),
                       String.valueOf(products.get(i).getPicture2()),
                       String.valueOf(products.get(i).getTypePrefix()),
                       String.valueOf(products.get(i).getVerdor()),
                       String.valueOf(products.get(i).getModel()),
                       String.valueOf(products.get(i).getParam1()),
                       String.valueOf(products.get(i).getParam2()),
                       String.valueOf(products.get(i).getParam3()),
                       String.valueOf(products.get(i).getParam4()),
                       String.valueOf(products.get(i).getParam5())
               );


           }


           //для toolbar
           toolbar = (Toolbar) findViewById(R.id.toolbar);
           tabLayout = (TabLayout)findViewById(R.id.tabLayout);
           viewPager =(ViewPager)findViewById(R.id.viewPager);
           viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
           viewPagerAdapter.addFragments(new RecyclerViewFragment() , Constants.CATEG_ALL);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg9() ,Constants.CATEG_9);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg10() ,Constants.CATEG_10);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg11() ,Constants.CATEG_11);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg12() ,Constants.CATEG_12);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg13() ,Constants.CATEG_13);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg14() ,Constants.CATEG_14);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg15() ,Constants.CATEG_15);
           viewPagerAdapter.addFragments(new RecyclerViewFragmentCateg16(), Constants.CATEG_16);
           viewPager.setAdapter(viewPagerAdapter);
           tabLayout.setupWithViewPager(viewPager);


   }catch(Exception ee){
       Intent intent = new Intent(this, MainActivityNotInternet.class);


       startActivity(intent);



   }



    }

    //метод проверки на инет
    public boolean isNetworkAvailable(final Context context) {
        final ConnectivityManager connectivityManager = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE));
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }



    public void showFragment(BaseFragment fragment, boolean addToBackStack, FragmentAnim fragmentAnim){


        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();


        if(fragmentAnim == FragmentAnim.RIGHT_TO_LEFT) {
            transaction.setCustomAnimations(R.anim.fragment_enter_from_right, R.anim.fragment_exit_to_left,
                    R.anim.fragment_enter_from_left, R.anim.fragment_exit_to_right);
        }




        transaction.replace(R.id.container, fragment,fragment.getFragmentTag());
        if(addToBackStack){

            transaction.addToBackStack(null);                                                         //TabLayout GitHub
        }


        transaction.commit();


    }


    @Override
    public void switchFragment(BaseFragment fragment, boolean addToBackStack, FragmentAnim fragmentAnim) {
        showFragment(fragment,addToBackStack, fragmentAnim);

    }

    //button in action bar


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_activity,menu);

        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.info_id:
                startActivity(new Intent(this, MainActivityInfo.class));
            //    this.finish();
                break;
            //

            case R.id.sync_id:
                startActivity(new Intent(this, MainActivity.class));
              //  this.finish();
                break;


            //
            case R.id.pool_id:
                startActivity(new Intent(this, MainActivityCode.class));
               // this.finish();
                break;





            //
        }

          return super.onOptionsItemSelected(item);


    }





}
