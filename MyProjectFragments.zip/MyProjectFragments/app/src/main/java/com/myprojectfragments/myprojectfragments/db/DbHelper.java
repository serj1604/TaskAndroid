package com.myprojectfragments.myprojectfragments.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.myprojectfragments.myprojectfragments.beans.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 29.04.2016.
 */
public class DbHelper extends SQLiteOpenHelper {

    private static final String TAG = DbHelper.class.getSimpleName();
    private static final String DATABASE_NAME = "madatabase";

    private static final int DATABASE_VERSION = 1;

    private List<Product> product_db_list;
    private List<Product> product_db_list_all;
    private List<Product> product_db_list_all_cotegory;

    private Product product;

    private int prod_id;
    private String prod_url;
    private String price;
    private String category;
    private String picture;
    private String picture1;
    private String picture2;
    private String typePrefix;
    private String verdor;
    private String model;
    private String param1;
    private String param2;
    private String param3;
    private String param4;
    private String param5;

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        Log.d(TAG, "onCreate()");


        db.execSQL("CREATE TABLE products_tab (prod_id INTEGER  " +
                ",prod_url TEXT " +
                ",price TEXT" +
                ",category TEXT" +
                ",picture TEXT" +
                ",picture1 TEXT" +
                ",picture2 TEXT" +
                ",typePrefix TEXT" +
                ",verdor TEXT" +
                ",model TEXT" +
                ",param1 TEXT" +
                ",param2 TEXT" +
                ",param3 TEXT" +
                ",param4 TEXT" +
                ",param5 TEXT)");

     //   db.execSQL("CREATE TABLE userdate (id INTEGER , date TEXT)");

        //создание второй таблицы для всех товаров products_tab_all
        db.execSQL("CREATE TABLE products_tab_all (prod_id INTEGER  " +
                ",prod_url TEXT " +
                ",price TEXT" +
                ",category TEXT" +
                ",picture TEXT" +
                ",picture1 TEXT" +
                ",picture2 TEXT" +
                ",typePrefix TEXT" +
                ",verdor TEXT" +
                ",model TEXT" +
                ",param1 TEXT" +
                ",param2 TEXT" +
                ",param3 TEXT" +
                ",param4 TEXT" +
                ",param5 TEXT)");







    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        Log.d(TAG, "onUpdate() old vertion " + oldVersion + "new version = " + newVersion);


    }

    public  void save(int prod_id,
                      String prod_url,
                      String price,
                      String category,
                      String picture,
                      String picture1,
                      String picture2,
                      String typePrefix,
                      String verdor,
                      String model,
                      String param1,
                      String param2,
                      String param3,
                      String param4,
                      String param5) {


        SQLiteDatabase db = getWritableDatabase();

        Log.d(TAG, "products_tab add");
        ContentValues values = new ContentValues();

            values.put("prod_id", prod_id);
            values.put("prod_url", prod_url);
            values.put("price", price);
            values.put("category", category);
            values.put("picture", picture);
            values.put("picture1", picture1);
            values.put("picture2", picture2);
            values.put("typePrefix", typePrefix);
            values.put("verdor", verdor);
            values.put("model", model);
            values.put("param1", param1);
            values.put("param2", param2);
            values.put("param3", param3);
            values.put("param4", param4);
            values.put("param5", param5);
            db.insert("products_tab", null, values);


            Log.d(TAG, "products_tab add");




        /*
        if (id > getUser().size()) {

            if (name != null || !name.equals("")) {
                Log.d(TAG, "id222Error ");

            } else {
                values.put("name", name);
                 db.insert("users", null, values);
                Log.d(TAG, "ADD User");
            }


        } else {
            values.put("name", name);
            db.update("users", values, "id=?", new String[]{String.valueOf(id)});
            Log.d(TAG, "UPDATE User");
        }


*/


        db.close();

    }

    /*
    public  void deleteRowTab(String prod_id){
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete("products_tab", "prod_id = " + prod_id, null);
        }catch(Exception e){}


    }
    */

    ///!!!! save product_ALL!!
    public  void saveALL(int prod_id,
                      String prod_url,
                      String price,
                      String category,
                      String picture,
                      String picture1,
                      String picture2,
                      String typePrefix,
                      String verdor,
                      String model,
                      String param1,
                      String param2,
                      String param3,
                      String param4,
                      String param5) {


        SQLiteDatabase db = getWritableDatabase();

        Log.d(TAG, "products_tab_all add");
        ContentValues values = new ContentValues();




     //   if ( getProduct_db_list_all().size()!=0) {



        values.put("prod_id", prod_id);
        values.put("prod_url", prod_url);
        values.put("price", price);
        values.put("category", category);
        values.put("picture", picture);
        values.put("picture1", picture1);
        values.put("picture2", picture2);
        values.put("typePrefix", typePrefix);
        values.put("verdor", verdor);
        values.put("model", model);
        values.put("param1", param1);
        values.put("param2", param2);
        values.put("param3", param3);
        values.put("param4", param4);
        values.put("param5", param5);
        db.insert("products_tab_all", null, values);


        Log.d(TAG, "products_tab_all add");


  //     } else {
        /*

            values.put("prod_id", prod_id);
            values.put("prod_url", prod_url);
            values.put("price", price);
            values.put("category", category);
            values.put("picture", picture);
            values.put("picture1", picture1);
            values.put("picture2", picture2);
            values.put("typePrefix", typePrefix);
            values.put("verdor", verdor);
            values.put("model", model);
            values.put("param1", param1);
            values.put("param2", param2);
            values.put("param3", param3);
            values.put("param4", param4);
            values.put("param5", param5);



            db.update("products_tab_all", values, "prod_id=?", new String[]{String.valueOf(prod_id)});
           Log.d(TAG, "UPDATE products_tab_all");
           */
    //    }




        /*
        if (id > getUser().size()) {


                values.put("name", name);
                 db.insert("users", null, values);
                Log.d(TAG, "ADD User");



        } else {
            values.put("name", name);
            db.update("users", values, "id=?", new String[]{String.valueOf(id)});
            Log.d(TAG, "UPDATE User");
        }


*/


        db.close();

    }



    public  void deleteRowTab(){
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete("products_tab", null, null);
        }catch(Exception e){}


    }


    public  void deleteRowTabALL(){
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete("products_tab_all", null, null);
        }catch(Exception e){}


    }


    public  List<Product> getProduct_db_list(){

        SQLiteDatabase db =   getReadableDatabase();


        String countQuery = "SELECT  * FROM " + "products_tab";
        Cursor cursor = db.rawQuery(countQuery, null);




        product_db_list = new ArrayList<Product>();

            try{

                cursor.moveToFirst();
                while (!cursor.isAfterLast()){

                    Log.d(TAG, "getProduct_db_list() do " + cursor.getString(cursor.getColumnIndex("prod_id")) );
                    prod_id = cursor.getInt(Integer.valueOf(cursor.getColumnIndex("prod_id")));


                    prod_url = cursor.getString(cursor.getColumnIndex("prod_url"));
                    price = cursor.getString(cursor.getColumnIndex("price"));
                    category= cursor.getString(cursor.getColumnIndex("category"));
                    picture = cursor.getString(cursor.getColumnIndex("picture"));
                    picture1 = cursor.getString(cursor.getColumnIndex("picture1"));
                    picture2 = cursor.getString(cursor.getColumnIndex("picture2"));
                    typePrefix = cursor.getString(cursor.getColumnIndex("typePrefix"));
                    verdor = cursor.getString(cursor.getColumnIndex("verdor"));
                    model = cursor.getString(cursor.getColumnIndex("model"));
                    param1 = cursor.getString(cursor.getColumnIndex("param1"));
                    param2 = cursor.getString(cursor.getColumnIndex("param2"));
                    param3 = cursor.getString(cursor.getColumnIndex("param3"));
                    param4 = cursor.getString(cursor.getColumnIndex("param4"));
                    param5 = cursor.getString(cursor.getColumnIndex("param5"));




                product = new Product();

                    product.setProd_id(Integer.valueOf(prod_id));
                    product.setProd_url(prod_url);
                    product.setPrice(price);
                    product.setCategory(category);
                    product.setPicture(picture);
                    product.setPicture1(picture1);
                    product.setPicture2(picture2);
                    product.setTypePrefix(typePrefix);
                    product.setVerdor(verdor);
                    product.setModel(model);
                    product.setParam1(param1);
                    product.setParam2(param2);
                    product.setParam3(param3);
                    product.setParam4(param4);
                    product.setParam5(param5);


                    product_db_list.add(product);

                    cursor.moveToNext();


                }


            }finally {

                cursor.close();
            }





            return product_db_list;


    }

//

    public  List<Product> getProduct_db_list_all(){

        SQLiteDatabase db =   getReadableDatabase();


        String countQuery = "SELECT  * FROM " + "products_tab_all";
        Cursor cursor = db.rawQuery(countQuery, null);




        product_db_list_all = new ArrayList<Product>();

        try{

            cursor.moveToFirst();
            while (!cursor.isAfterLast()){

                Log.d(TAG, "getProduct_db_list() do " + cursor.getString(cursor.getColumnIndex("prod_id")) );
                prod_id = cursor.getInt(Integer.valueOf(cursor.getColumnIndex("prod_id")));


                prod_url = cursor.getString(cursor.getColumnIndex("prod_url"));
                price = cursor.getString(cursor.getColumnIndex("price"));
                category= cursor.getString(cursor.getColumnIndex("category"));
                picture = cursor.getString(cursor.getColumnIndex("picture"));
                picture1 = cursor.getString(cursor.getColumnIndex("picture1"));
                picture2 = cursor.getString(cursor.getColumnIndex("picture2"));
                typePrefix = cursor.getString(cursor.getColumnIndex("typePrefix"));
                verdor = cursor.getString(cursor.getColumnIndex("verdor"));
                model = cursor.getString(cursor.getColumnIndex("model"));
                param1 = cursor.getString(cursor.getColumnIndex("param1"));
                param2 = cursor.getString(cursor.getColumnIndex("param2"));
                param3 = cursor.getString(cursor.getColumnIndex("param3"));
                param4 = cursor.getString(cursor.getColumnIndex("param4"));
                param5 = cursor.getString(cursor.getColumnIndex("param5"));




                product = new Product();

                product.setProd_id(Integer.valueOf(prod_id));
                product.setProd_url(prod_url);
                product.setPrice(price);
                product.setCategory(category);
                product.setPicture(picture);
                product.setPicture1(picture1);
                product.setPicture2(picture2);
                product.setTypePrefix(typePrefix);
                product.setVerdor(verdor);
                product.setModel(model);
                product.setParam1(param1);
                product.setParam2(param2);
                product.setParam3(param3);
                product.setParam4(param4);
                product.setParam5(param5);


                product_db_list_all.add(product);

                cursor.moveToNext();


            }


        }finally {

            cursor.close();
        }





        return product_db_list_all;


    }

    public  List<Product> getProduct_db_list_all_category(String category){

        SQLiteDatabase db =   getReadableDatabase();


        String countQuery = "SELECT  * FROM " + "products_tab_all WHERE category = " + category;
        Cursor cursor = db.rawQuery(countQuery, null);




        product_db_list_all_cotegory = new ArrayList<Product>();

        try{

            cursor.moveToFirst();
            while (!cursor.isAfterLast()){

                Log.d(TAG, "getProduct_db_list() do " + cursor.getString(cursor.getColumnIndex("prod_id")) );
                prod_id = cursor.getInt(Integer.valueOf(cursor.getColumnIndex("prod_id")));


                prod_url = cursor.getString(cursor.getColumnIndex("prod_url"));
                price = cursor.getString(cursor.getColumnIndex("price"));
                category= cursor.getString(cursor.getColumnIndex("category"));
                picture = cursor.getString(cursor.getColumnIndex("picture"));
                picture1 = cursor.getString(cursor.getColumnIndex("picture1"));
                picture2 = cursor.getString(cursor.getColumnIndex("picture2"));
                typePrefix = cursor.getString(cursor.getColumnIndex("typePrefix"));
                verdor = cursor.getString(cursor.getColumnIndex("verdor"));
                model = cursor.getString(cursor.getColumnIndex("model"));
                param1 = cursor.getString(cursor.getColumnIndex("param1"));
                param2 = cursor.getString(cursor.getColumnIndex("param2"));
                param3 = cursor.getString(cursor.getColumnIndex("param3"));
                param4 = cursor.getString(cursor.getColumnIndex("param4"));
                param5 = cursor.getString(cursor.getColumnIndex("param5"));




                product = new Product();

                product.setProd_id(Integer.valueOf(prod_id));
                product.setProd_url(prod_url);
                product.setPrice(price);
                product.setCategory(category);
                product.setPicture(picture);
                product.setPicture1(picture1);
                product.setPicture2(picture2);
                product.setTypePrefix(typePrefix);
                product.setVerdor(verdor);
                product.setModel(model);
                product.setParam1(param1);
                product.setParam2(param2);
                product.setParam3(param3);
                product.setParam4(param4);
                product.setParam5(param5);


                product_db_list_all_cotegory.add(product);

                cursor.moveToNext();


            }


        }finally {

            cursor.close();
        }





        return product_db_list_all_cotegory;


    }







}
