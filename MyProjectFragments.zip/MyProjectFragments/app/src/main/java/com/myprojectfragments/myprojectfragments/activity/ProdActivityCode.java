package com.myprojectfragments.myprojectfragments.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.myprojectfragments.myprojectfragments.R;
import com.squareup.picasso.Picasso;


public class ProdActivityCode extends Activity {


    TextView  tv_url;
    TextView  tv_typePrefix;
    TextView  tv_model;
    TextView  tv_verdor;
    TextView  tv_price;
    TextView  tv_picture;
    ImageView productPhoto;

    private Context context;

    Button buttgame;

    String url_prod ;
    String price_prod ;
    String picture_prod ;
    String typePrefix_prod ;
    String verdor_prod  ;
    String model_prod ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_code);


        productPhoto = (ImageView) findViewById(R.id.product_photo);
      //  tv = (TextView) findViewById(R.id.tv_prod);

          tv_url = (TextView) findViewById(R.id.tv_url);
          tv_typePrefix = (TextView) findViewById(R.id.tv_typePrefix);
          tv_model = (TextView) findViewById(R.id.tv_model);
          tv_verdor = (TextView) findViewById(R.id.tv_verdor);
          tv_price = (TextView) findViewById(R.id.tv_price);
          tv_picture = (TextView) findViewById(R.id.tv_picture);

        buttgame = (Button) findViewById(R.id.buttgame);









        Intent intent = getIntent();




         url_prod = getIntent().getExtras().getString("key_url");
         price_prod = getIntent().getExtras().getString("key_price");
         picture_prod = getIntent().getExtras().getString("key_picture");
         typePrefix_prod = getIntent().getExtras().getString("key_typePrefix");
         verdor_prod = getIntent().getExtras().getString("key_verdor");
         model_prod = getIntent().getExtras().getString("key_model");

        //если товар стоит меньше 10 р. то кнопка game невидима
        if(Integer.valueOf(price_prod)<10){

            buttgame.setVisibility(View.INVISIBLE);
        }



        String s = "URL: " + url_prod +
                ",  Название товара: " + typePrefix_prod +
                ",  Модель: " + model_prod +
                ",  Модель: " + verdor_prod +
                ",  Цена товара: " + price_prod  +
                ",  Картинка товара: " + picture_prod;

          tv_url.setText("URL: " +url_prod);
          tv_typePrefix.setText("Название товара: " + typePrefix_prod);
          tv_model.setText("Модель: " +model_prod);
          tv_verdor.setText("Модель: " +verdor_prod);
          tv_price.setText("Цена товара: " +price_prod);
          tv_picture.setText("Картинка товара: " + picture_prod);

   //     productPhoto.setImageResource(R.drawable.intex);
  //    Picasso.with(context).load(picture_prod).resize(300, 300).into(productPhoto);
       Picasso.with(context).load(picture_prod).into(productPhoto);

        buttgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  передача данных в gameactivity
                Intent intent = new Intent(ProdActivityCode.this, GameActivity.class);
                intent.putExtra("game_url",url_prod );
                intent.putExtra("game_price",price_prod );
                intent.putExtra("game_typePrefix",typePrefix_prod );
                intent.putExtra("game_model",model_prod );
                intent.putExtra("game_verdor",verdor_prod );


                startActivity(intent);


            }
        });












    }

}
