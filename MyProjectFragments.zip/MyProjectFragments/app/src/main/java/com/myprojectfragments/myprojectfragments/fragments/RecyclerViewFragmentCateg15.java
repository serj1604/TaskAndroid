package com.myprojectfragments.myprojectfragments.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.PagerAdapter;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.myprojectfragments.myprojectfragments.db.DbHelper;
import com.myprojectfragments.myprojectfragments.parses.ParseMagic;
import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.R;
import com.myprojectfragments.myprojectfragments.adapters.RVAdapter;
import com.myprojectfragments.myprojectfragments.listeners.ToolbarListener;
import com.myprojectfragments.myprojectfragments.activity.MainActivity;
import com.myprojectfragments.myprojectfragments.activity.MainActivityProduct;

import java.util.List;

/**
 * Created by Администратор on 10.05.2016.
 */
public class RecyclerViewFragmentCateg15 extends BaseFragment {

    private  static final String TAG= RecyclerViewFragmentCateg15.class.getSimpleName();
    private DbHelper dbHelper;
    private ToolbarListener mToolbarListener;
    private PagerAdapter myAdapter;

    RVAdapter adapter = null;
    List<Product> products;
    List<Product> products_k;
    ParseMagic mt;
    RecyclerView rv;

    public static RecyclerViewFragmentCateg15 getInstance(FragmentManager fragmentManager) {


        RecyclerViewFragmentCateg15 myFragment = (RecyclerViewFragmentCateg15) fragmentManager.findFragmentByTag(RecyclerViewFragmentCateg15.TAG);

        if (myFragment == null) {
            myFragment = new RecyclerViewFragmentCateg15();


        }

        return myFragment;

    }



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_main_list_categ15, container,false);


        rv = (RecyclerView) view.findViewById(R.id.rv15);

/*
        mt = new ParseMagic();
        mt.execute();

        try {
            products = mt.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
*/

        dbHelper = new DbHelper(getActivity().getApplicationContext());
        products_k = dbHelper.getProduct_db_list_all_category(String.valueOf(15));


        /*
        products = dbHelper.getProduct_db_list_all();
        //перебрать products по категориям и засунуть в другой List
        products_k = new ArrayList<>();
        for(int i=0;i<products.size();i++){
         //   if (products.get(i).getCategory().equals(String.valueOf(9))){
            Log.d("Category PRODUCT_K !!!", products.get(i).getCategory());
                if (Integer.valueOf(products.get(i).getCategory())==15){
                products_k.add(products.get(i));
                Log.d("Categ++ PRODUCT_K +!+", products.get(i).getCategory());


            }


        }

*/





        GridLayoutManager GridLayoutManager = new GridLayoutManager(getActivity(), 2);
        rv.setLayoutManager(GridLayoutManager);

      ///  adapter = new RVAdapter(getActivity().getApplicationContext(),products);
        adapter = new RVAdapter(getActivity().getApplicationContext(),products_k);
        rv.setAdapter(adapter);






        //---------передача данных=======================
        rv.addOnItemTouchListener(new RecyclerTouchListener(getActivity().getApplicationContext(), rv, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Product prod = products_k.get(position);
                Toast.makeText(getActivity().getApplicationContext(), String.valueOf(prod.getProd_id()) + " is selected!", Toast.LENGTH_SHORT).show();
                // тут переход на новую активити
                // сохранить в БазуДанных

                dbHelper = new DbHelper(getActivity().getApplicationContext());
             dbHelper.deleteRowTab( );
           //     dbHelper.deleteRowTab( String.valueOf(1));

             dbHelper.save(
                     Integer.valueOf(prod.getProd_id()),
                     String.valueOf(prod.getProd_url()),
                     String.valueOf(prod.getPrice()),
                     String.valueOf(prod.getCategory()),
                     String.valueOf(prod.getPicture()),
                     String.valueOf(prod.getPicture1()),
                     String.valueOf(prod.getPicture2()),
                     String.valueOf(prod.getTypePrefix()),
                     String.valueOf(prod.getVerdor()),
                     String.valueOf( prod.getModel()),
                     String.valueOf(prod.getParam1()),
                     String.valueOf(prod.getParam2()),
                     String.valueOf(prod.getParam3()),
                     String.valueOf(prod.getParam4()),
                     String.valueOf(prod.getParam5())
             );


                //********************************

          //      ViewPager pager =(ViewPager)view.findViewById(R.id.pager);

           //     pager.setAdapter(myAdapter);


                Intent intent = new Intent( (MainActivity)getActivity(), MainActivityProduct.class);
                ((MainActivity) getActivity()).startActivity(intent);



              //  getActivity().showProductFragment();
            //   ProductFragment pf = new ProductFragment();

                    //   ((MainActivity) getActivity()).showFragment(pf, true,FragmentAnim.RIGHT_TO_LEFT);
         //       Intent intent = new Intent((MainActivity) getActivity(), MainActivityProduct.class);
         //       startActivity(intent);


            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));



        //---------end передача данных=======================






        return view;
    }




    //----------------
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    //--------------







    @Override
    public String getFragmentTag() {
        return TAG;
    }











}
