package com.myprojectfragments.myprojectfragments.handlers;

import android.util.Log;

import com.myprojectfragments.myprojectfragments.beans.Product;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;


public class Producthandler extends DefaultHandler {

  //  Attributes attributes;
    Boolean currentElement = false;
    String currentValue = "";
    Product prod = null;
    private ArrayList<Product> ProductList = new ArrayList<Product>();

    public ArrayList<Product> getProductLists() {
        return ProductList;
    }








    // Called when tag starts
    @Override
    public void startElement(String uri, String localName, String qName,
                             Attributes attributes) throws SAXException {

        currentElement = true;
        currentValue = "";
        if (localName.equals("offer")) {
            prod = new Product();



            if (attributes.getValue("id")!=null) {
               prod.setProd_id(Integer.valueOf(attributes.getValue("id")));
                Log.d("ID !!!", attributes.toString());
                Log.w("ID !!!", String.valueOf(attributes.getValue("id")));//работает

          }




        }


    }


    // Called when tag closing
    @Override
    public void endElement(String uri, String localName, String qName)
            throws SAXException {

        currentElement = false;
        String par = "";

        if (localName.equalsIgnoreCase("url")) {

            if (currentValue.equalsIgnoreCase("http://lovivolny.by/"))
                Log.d("url !!!", currentValue);
            else {
                prod.setProd_url(currentValue);
                Log.d("url !!!", currentValue);
            }
            //  price
        } else if (localName.equalsIgnoreCase("price")) {
            prod.setPrice(currentValue);
            Log.d("price", currentValue);
        } else if (localName.equalsIgnoreCase("categoryId")) {
            prod.setCategory(currentValue);
            Log.d("categoryId", currentValue);
        }


        // picture
        else if (localName.equalsIgnoreCase("picture")) {


            if (prod.getPicture() == null) {
                prod.setPicture(currentValue);

            } else if (prod.getPicture1() == null) {
                prod.setPicture1(currentValue);

            } else if (prod.getPicture2() == null) {
                prod.setPicture2(currentValue);
            }




            Log.d("picture", currentValue);
        }



        // typePrefix
        else if (localName.equalsIgnoreCase("typePrefix")) {
            prod.setTypePrefix(currentValue);
            Log.d("setTypePrefix", currentValue);
        }
        // vendor
        else if (localName.equalsIgnoreCase("vendor"))
            prod.setVerdor(currentValue);
            // model
        else if (localName.equalsIgnoreCase("model"))
            prod.setModel(currentValue);




        else if (localName.equalsIgnoreCase("param")) {
            if(prod.getParam1()==null) {
                if(currentValue!=null)
               prod.setParam1(currentValue);

            }
            else if(prod.getParam2()==null) {
                if(currentValue!=null)
                prod.setParam2(currentValue);
            }
            else if(prod.getParam3()==null) {
                if(currentValue!=null)
                prod.setParam3(currentValue);
            }
            else if(prod.getParam4()==null) {
                if(currentValue!=null)
                prod.setParam4(currentValue);
            }
            else if(prod.getParam5()==null) {
                if(currentValue!=null)
                prod.setParam5(currentValue);

            }


//
        } else if (localName.equalsIgnoreCase("offer")) {


            ProductList.add(prod);

        }

    }



    // Called to get tag characters
    @Override
    public void characters(char[] ch, int start, int length)
            throws SAXException {

        if (currentElement) {
            currentValue = currentValue + new String(ch, start, length);

        }

    }





}