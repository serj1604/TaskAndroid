package com.myprojectfragments.myprojectfragments.fragments;

import android.support.v4.app.Fragment;

/**
 * Created by user on 06.05.2016.
 */
public abstract class BaseFragment extends Fragment {

    public abstract String getFragmentTag();






}
