package com.myprojectfragments.myprojectfragments.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.myprojectfragments.myprojectfragments.db.DbHelper;
import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.R;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Администратор on 14.05.2016.
 */
public class Fragment_pic1 extends Fragment {
    private  static final String TAG= Fragment_pic1.class.getSimpleName();
    private DbHelper dbHelper;
    List<Product> products;
    String picture_prod ;
    private Context context;
    ImageView productPhoto;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.pic1_layout, null);

        productPhoto = (ImageView) view.findViewById(R.id.product_photo_picture1);

        dbHelper = new DbHelper(getActivity().getApplicationContext());
        products = dbHelper.getProduct_db_list();

        picture_prod = products.get(0).getPicture();
       Log.d(TAG, "Fragment_pic1 " + picture_prod);
        //product_photo_picture1
        Picasso.with(context).load(picture_prod).into(productPhoto);



        return view;
    }



}
