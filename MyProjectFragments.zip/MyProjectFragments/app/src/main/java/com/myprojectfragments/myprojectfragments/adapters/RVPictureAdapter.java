package com.myprojectfragments.myprojectfragments.adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.myprojectfragments.myprojectfragments.beans.Picture;
import com.myprojectfragments.myprojectfragments.R;
import com.squareup.picasso.Picasso;

import java.util.List;


public class RVPictureAdapter extends RecyclerView.Adapter<RVPictureAdapter.ProductViewHolder> {
    List<Picture> products;
    private static final String TAG = "MainActivity for photo";

    private Context context;




    public class ProductViewHolder extends RecyclerView.ViewHolder {

        CardView cv_picture;
        ImageView productPhoto;

        ProductViewHolder(View itemView) {
            super(itemView);
            cv_picture = (CardView) itemView.findViewById(R.id.cv_picture);


            productPhoto = (ImageView) itemView.findViewById(R.id.product_photo_picture);
        }





    }



//конструктор для фото
    public RVPictureAdapter(Context context, List<Picture> products){

        this.context = context;

        this.products = products;
    }




        @Override
        public int getItemCount() {
            return products.size();
        }


        @Override
        public ProductViewHolder onCreateViewHolder(ViewGroup parent, int i) {



            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cv_picture_layout, parent, false);
            ProductViewHolder pvh = new ProductViewHolder(v);
            return pvh;


        }


        @Override
        public void onBindViewHolder(ProductViewHolder holder, int position) {



            Log.i(TAG, "chek URL !!!!" + products.get(position).getPicture_link());
           Picasso.with(context).load(products.get(position).getPicture_link()).into(holder.productPhoto);
        //    Picasso.with(context).load(products.get(position).getPicture_link()).resize(300, 300).into(holder.productPhoto);
      //      Picasso.with(context).load(products.get(position).getPicture()).into(holder.productPhoto);






        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }


}
