package com.myprojectfragments.myprojectfragments.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.R;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Администратор on 09.04.2016.
 */
public class RVAdapter extends RecyclerView.Adapter<RVAdapter.ProductViewHolder> {
    List<Product> products;
    private static final String TAG = "MainActivity for photo";

    private Context context;

    public class ProductViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        TextView productName;
        TextView productPrice;
        TextView productModel;
        TextView productVerdor;

        ImageView productPhoto;

        ProductViewHolder(View itemView) {
            super(itemView);
            cv = (CardView) itemView.findViewById(R.id.cv);
            productName = (TextView) itemView.findViewById(R.id.product_name);
            productPrice = (TextView) itemView.findViewById(R.id.product_price);
            productModel = (TextView) itemView.findViewById(R.id.product_model);
            productVerdor = (TextView) itemView.findViewById(R.id.product_verdor);


            productPhoto = (ImageView) itemView.findViewById(R.id.product_photo);
        }

        //-------------------!!!! photo
       public void bindDrawable(Drawable drawable){

           productPhoto.setImageDrawable(drawable);
       }
       //--------



    }



//конструктор для фото
    public RVAdapter(Context context, List<Product> products){

        this.context = context;

        this.products = products;
    }


        @Override
        public int getItemCount() {
            return products.size();
        }


        @Override
        public ProductViewHolder onCreateViewHolder(ViewGroup parent, int i) {



            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cv_layout, parent, false);
            ProductViewHolder pvh = new ProductViewHolder(v);
            return pvh;









        }


        @Override
        public void onBindViewHolder(ProductViewHolder holder, int position) {

            holder.productName.setText(products.get(position).getTypePrefix());
            holder.productPrice.setText(products.get(position).getPrice()+ " р.");
            holder.productModel.setText(products.get(position).getVerdor() );
            holder.productVerdor.setText(products.get(position).getModel() );

            Log.i(TAG, "chek URL !!!!" + products.get(position).getPicture());

         ///  Picasso.with(context).load(products.get(position).getPicture()).resize(300, 300).into(holder.productPhoto);
            Picasso.with(context).load(products.get(position).getPicture()).resize(400, 400).into(holder.productPhoto);


        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }


}
