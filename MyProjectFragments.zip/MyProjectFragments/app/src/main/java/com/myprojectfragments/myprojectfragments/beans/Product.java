package com.myprojectfragments.myprojectfragments.beans;

/**
 * Created by Администратор on 09.04.2016.
 */
public class Product {


    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    private String bank;
    private String procbank;

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getProcbank() {
        return procbank;
    }

    public void setProcbank(String procbank) {
        this.procbank = procbank;
    }
//  private String prod_id;

    private int prod_id;

    public int getProd_id() {
        return prod_id;
    }

    public void setProd_id(int prod_id) {
        this.prod_id = prod_id;
    }

    private String prod_url;
    private String price;
    private String category;
    private String picture;
    private String picture1;
    private String picture2;
    private String typePrefix;
    private String verdor;
    private String model;
    private String param1;
    private String param2;
    private String param3;
    private String param4;
    private String param5;

    public String getParam2() {
        return param2;
    }

    public void setParam2(String param2) {
        this.param2 = param2;
    }

    public String getParam3() {
        return param3;
    }

    public void setParam3(String param3) {
        this.param3 = param3;
    }

    public String getParam4() {
        return param4;
    }

    public void setParam4(String param4) {
        this.param4 = param4;
    }

    public String getParam5() {
        return param5;
    }

    public void setParam5(String param5) {
        this.param5 = param5;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPicture1() {
        return picture1;
    }

    public void setPicture1(String picture1) {
        this.picture1 = picture1;
    }

    public String getPicture2() {
        return picture2;
    }

    public void setPicture2(String picture2) {
        this.picture2 = picture2;
    }

    public String getParam1() {
        return param1;
    }

    public void setParam1(String param1) {
        this.param1 = param1;
    }



  //  public String getProd_id() {
   //     return prod_id;
  //  }

  //  public void setProd_id(String prod_id) {
  //      this.prod_id = prod_id;
  //  }



    public String getProd_url() {
        return prod_url;
    }

    public void setProd_url(String prod_url) {
        this.prod_url =prod_url;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getTypePrefix() {
        return typePrefix;
    }

    public void setTypePrefix(String typePrefix) {
        this.typePrefix = typePrefix;
    }

    public String getVerdor() {
        return verdor;
    }

    public void setVerdor(String verdor) {
        this.verdor = verdor;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }







}
