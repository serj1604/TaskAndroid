package com.myprojectfragments.myprojectfragments.parses;


import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import com.myprojectfragments.myprojectfragments.beans.Product;
import com.myprojectfragments.myprojectfragments.db.DbHelper;
import com.myprojectfragments.myprojectfragments.handlers.Producthandler;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class ParseMagic extends AsyncTask<String, String, ArrayList<Product>> {

    ProgressDialog dialog;
    Context context;
    private DbHelper dbHelper;
    TextView xmlOutput = null;
    ProgressDialog progress = null;

    String response = null;
    @Override
    protected void onPreExecute(){

     //   this.dialog = new ProgressDialog(context);
    //    this.dialog.setMessage(context.getResources().getString(R.string.loading));

    //    if(!dialog.isShowing()){
     //       dialog.show();
     //   }



    }


    @Override
    protected ArrayList<Product> doInBackground(String... arg0) {







        String myFeed = "http://lovivolny.by/yml";
        String parsedData = "";
        ArrayList<Product> ProductsList = null;
        try {

            Log.w("AndroidParseXMLActivity", "Start");
            SAXParserFactory spf = SAXParserFactory.newInstance();
            SAXParser sp = spf.newSAXParser();
            XMLReader xr = sp.getXMLReader();

            //*********************************
            URL sourceURL = new URL("http://lovivolny.by/yml");
            //*******************************
            Producthandler XMLHandler = new Producthandler();
            xr.setContentHandler(XMLHandler);
            xr.parse(new InputSource(sourceURL.openStream()));

            //  Log.w("response", response);
            int i = 0;
            ProductsList = XMLHandler.getProductLists();



            for (i = 0; i < ProductsList.size(); i++) {
                Product prod = ProductsList.get(i);
                parsedData = parsedData + "ofter " + (i + 1) + "Detail----->\n";
                parsedData = parsedData + "ID!!!: " + String.valueOf(prod.getProd_id()) + "\n";

                parsedData = parsedData + "url: " + prod.getProd_url() + "\n";
                parsedData = parsedData + "price: " + prod.getPrice() + "\n";
                parsedData = parsedData + "category: " + prod.getCategory() + "\n";

                parsedData = parsedData + "picture: " + prod.getPicture() + "\n";
                parsedData = parsedData + "picture1: " + prod.getPicture1() + "\n";
                parsedData = parsedData + "picture2: " + prod.getPicture2() + "\n";

                parsedData = parsedData + "typePrefix: " + prod.getTypePrefix() + "\n";
                parsedData = parsedData + "vendor: " + prod.getVerdor() + "\n";
                parsedData = parsedData + "model: " + prod.getModel() + "\n";
                parsedData = parsedData + "param1: " + prod.getParam1() + "\n";
                parsedData = parsedData + "param2: " + prod.getParam2() + "\n";
                parsedData = parsedData + "param3: " + prod.getParam3() + "\n";
                parsedData = parsedData + "param4: " + prod.getParam4() + "\n";
                parsedData = parsedData + "param5: " + prod.getParam5() + "\n";

/*
                dbHelper.saveALL(
                        prod.getProd_id(),
                        String.valueOf(prod.getProd_url()),
                        String.valueOf(prod.getPrice()),
                        String.valueOf(prod.getCategory()),
                        String.valueOf(prod.getPicture()),
                        String.valueOf(prod.getPicture1()),
                        String.valueOf(prod.getPicture2()),
                        String.valueOf(prod.getTypePrefix()),
                        String.valueOf(prod.getVerdor()),
                        String.valueOf(prod.getModel()),
                        String.valueOf(prod.getParam1()),
                        String.valueOf(prod.getParam2()),
                        String.valueOf(prod.getParam3()),
                        String.valueOf(prod.getParam4()),
                        String.valueOf(prod.getParam5())

                );

                Log.w("prod save ALL== ", prod.getModel());

*/


            }
            Log.w("i==", String.valueOf(i));
            Log.w("Data", parsedData);

            //  Log.w("ParsingXml and populating", "Done");



            //---------------------------


        } catch (Exception e) {
            e.printStackTrace();
        }


     //   return parsedData;
        return ProductsList;

    }
    protected void onPostExecute(ArrayList<Product> ab){
        //progress.dismiss();
        super.onPostExecute(ab);
    //    this.dialog.dismiss();



    }

}
