package com.myprojectfragments.myprojectfragments.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Администратор on 21.05.2016.
 */
public class ViewPagerAdapter extends FragmentPagerAdapter {

    List<Fragment> fragments  = new ArrayList<>();
    List<String> tabTitles = new ArrayList<>();




    public void addFragments(Fragment fragments,String titles){
        this.fragments.add(fragments);
        this.tabTitles.add(titles);

    }



    /*
     public PagerAdapterPic(FragmentManager fm,List<Fragment> fragments ) {
        super(fm);
        this.fragments = fragments;

    }


     */


    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }

  //  public ViewPagerAdapter(FragmentManager fm, List<Fragment> fragments) {
    //    super(fm);
      //  this.fragments = fragments;
   // }



    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
       return fragments.size();
      //  return 3;

    }


    @Override
    public CharSequence getPageTitle(int position) {
        return tabTitles.get(position);
    }
}
