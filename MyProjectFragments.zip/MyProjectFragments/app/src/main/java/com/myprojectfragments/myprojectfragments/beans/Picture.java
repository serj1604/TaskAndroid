package com.myprojectfragments.myprojectfragments.beans;

/**
 * Created by Администратор on 09.04.2016.
 */
public class Picture {
    public Picture(String picture_link) {
        this.picture_link = picture_link;
    }
//  private String prod_id;

    private String picture_link;

    public String getPicture_link() {
        return picture_link;
    }

    public void setPicture_link(String picture_link) {
        this.picture_link = picture_link;
    }
}
