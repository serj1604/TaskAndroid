package com.myfirstbutton.serj.firstbutton;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity implements View.OnClickListener {

    TextView text1;
    TextView text2;
    String text;
    Button but1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        text1 = (TextView)findViewById(R.id.tv_1);
        text2 = (TextView)findViewById(R.id.tv_2);
        but1 = (Button)findViewById(R.id.but1);



        //text 1
        text1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    text = (String) text1.getText();
                    text1.setText(text2.getText());
                    text2.setText(text);


            }
        });
        text2.setOnClickListener(this);


    }

    // text 2
    @Override
    public void onClick(View view) {

        text = (String) text1.getText();
        text1.setText(text2.getText());
        text2.setText(text);

    }

    //but1
    public void onMyButtonClick(View view){

        text = (String) text1.getText();
        text1.setText(text2.getText());
        text2.setText(text);

    }


}
