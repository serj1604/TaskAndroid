package com.myfirstservice.myfirstservice;

/**
 * Created by Администратор on 10.04.2016.
 */
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public class MyService extends Service {

  //  public final static String PARAM_RESULT = "result";
    final String LOG_TAG = "myLogs";
    ExecutorService es;

    public void onCreate() {
        super.onCreate();
        Log.d(LOG_TAG, "onCreate");
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(LOG_TAG, "onStartCommand");



        int task = intent.getIntExtra(MainActivity.PARAM_TASK, 0);


        someTask();

        return super.onStartCommand(intent, flags, startId);
    }

    public void onDestroy() {
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");
    }

    public IBinder onBind(Intent intent) {
        Log.d(LOG_TAG, "onBind");
        return null;
    }

    void someTask()  {
        new Thread(new Runnable() {
            public void run() {
                Intent intent = new Intent(MainActivity.BROADCAST_ACTION);



                for (int i = 1; i<=50; i++) {
                    Log.d(LOG_TAG, "i = " + i);
                    try {


                        intent.putExtra(MainActivity.PARAM_RESULT, i);
                        sendBroadcast(intent);

                        TimeUnit.SECONDS.sleep(5);



                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                stopSelf();
            }
        }).start();

    }
}
