package com.myfirstservice.myfirstservice;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends Activity {

    final int TASK1_CODE = 1;
    public final static String PARAM_TIME = "time";

   ///------------------------------

    final String LOG_TAG = "myLogs";
    public final static String PARAM_TASK = "task";
    public final static String PARAM_RESULT = "result";
    public final static String BROADCAST_ACTION = "ru.startandroid.develop.p0912896361servicebackbroadcast";
    TextView text2;

    BroadcastReceiver br;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text2 = (TextView) findViewById(R.id.text2);
        text2.setText("result");


        // создаем BroadcastReceiver
        br = new BroadcastReceiver() {
            // действия при получении сообщений
            public void onReceive(Context context, Intent intent) {
                int result = intent.getIntExtra(PARAM_RESULT, 0);
                text2.setText("Result = " + result);
                Log.d(LOG_TAG, "onReceive: ");
            }
        };

        // создаем фильтр для BroadcastReceiver
        IntentFilter intFilt = new IntentFilter(BROADCAST_ACTION);
        // регистрируем (включаем) BroadcastReceiver
        registerReceiver(br, intFilt);



    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // дерегистрируем (выключаем) BroadcastReceiver
        unregisterReceiver(br);
    }


    public void onClickStart(View v) {
      //  startService(new Intent(this, MyService.class));
        Intent intent;

        // Создаем Intent для вызова сервиса,
        // кладем туда параметр времени и код задачи
        intent = new Intent(this, MyService.class).putExtra(PARAM_TIME, 7)
                .putExtra(PARAM_TASK, TASK1_CODE);
        // стартуем сервис
        startService(intent);

    }

   // public void onClickStop(View v) {
      //  stopService(new Intent(this, MyService.class));
   // }

}
